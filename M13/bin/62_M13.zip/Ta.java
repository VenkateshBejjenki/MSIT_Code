/*
 * Author :- Rajesh Kumar Sheela
 */
interface MSITStudent{
	void getGPA();
}
interface MSITMentor{
	
	void getSalary();
}


public class Ta implements MSITStudent, MSITMentor {

	String name;
	int roll;
	public void getGPA() {
		
	}

	public void getSalary() {
		
		
	} 
   
}


