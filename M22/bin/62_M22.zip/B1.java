import java.util.Hashtable;
import java.util.Map;

/*
 * Program :- i.Create a Student Hash Table to store n number of students with respect to their registration number. 
  ii.Take registration number as input and remove respective student details.
  
  Author :- Rajesh Kumar Sheela
  */
public class B1 {

	public static void main(String[] args) {
		
		Hashtable<Integer, String> stb=new Hashtable<Integer, String>();
		stb.put(2, "rajesh");
		stb.put(1, "kumar");
		stb.put(3, "Sheela");
		
		stb.remove(1);
		for(Map.Entry m:stb.entrySet()){
			System.out.println(m.getKey()+" "+m.getValue());
		}
		

	}

}
