package da10;

interface Queues {

	void Enqueue(String x);
	void Dqueue();
	void Frount();
	boolean isEmpty();
	void Display();
}
