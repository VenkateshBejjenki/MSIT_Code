

import java.io.IOException;

import console.MainMenu;


public class PPSystem 
{

	public static void main(String[] args) throws IOException 
	{
		MainMenu.show();
	}

}
