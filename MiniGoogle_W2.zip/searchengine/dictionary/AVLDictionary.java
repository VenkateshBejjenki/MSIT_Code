package searchengine.dictionary;

public class AVLDictionary <K extends Comparable<K>, V> implements DictionaryInterface <K,V>{

	@Override
	public K[] getKeys() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public V getValue(K str) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insert(K key, V value) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void remove(K key) {
		// TODO Auto-generated method stub
		
	}

}
