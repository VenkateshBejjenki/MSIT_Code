/*
 Program:-First Java program, which says "Hello, world!"
 Author:-Rajesh Kumar Sheela
 */
public class task1 {	// Save as "task1.java"
	public static void main(String[] args) {
		
		System.out.println("Hello World!"); // print message

	}

}
