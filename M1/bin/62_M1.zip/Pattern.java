/*
 Program:-Write a Java Program to print *** (--!--) ++++ on screen? 
 Author:-Rajesh Kumar Sheela
 */

public class Pattern {

	public static void main(String[] args) {
		
		System.out.println("*** (--!--) ++++");
	}

}
