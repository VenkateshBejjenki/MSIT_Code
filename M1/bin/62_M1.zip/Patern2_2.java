/*
 Program:-Print each of the following patterns. Use one System.out.println(...) statement for each line of outputs.  
 Author:-Rajesh Kumar Sheela
 */

public class Patern2_2 {

	public static void main(String[] args) {
		
		System.out.println("* * * * *");
		System.out.println("*       *");
		System.out.println("*       *");
		System.out.println("*       *");
		System.out.println("* * * * *");
	}

}
