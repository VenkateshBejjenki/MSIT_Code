/*
 Program:- Write a Java Program to print your name on screen? 
 Author:-Rajesh Kumar Sheela
 */
public class Name {

	public static void main(String[] args) {
		
		System.out.println("Rajesh Kumar Sheela");

	}

}
