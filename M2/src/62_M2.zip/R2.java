/*
 Author:-Rajesh Kumar Sheela
 Program:- 2. void main(){
				int x = 10, y = 5, z;
				printf(“%d”,x*y);
				z = x/y;
				printf(“%d”,z);
			}
 */
public class R2 {
	public static void main(String[] args) {
		int x = 10, y = 5, z;
		System.out.println("Product of two numbers are :- "+x*y);
		z = x/y;
		System.out.println("Division is :- "+z);

	}

}
