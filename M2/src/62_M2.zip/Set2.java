/*
 Author:-Rajesh Kumar Sheela
 Program:- Write a Java program to given int number is EVEN or ODD? 
 */
public class Set2 {
	public static void main(String[] args) {
		int number = 49;       // set the value of number here!
	      System.out.println("The number is " + number);
	      if (number%2==0) {
	         System.out.println("Even");
	      } else {
	         System.out.println("Odd");
	      }

	}

}
