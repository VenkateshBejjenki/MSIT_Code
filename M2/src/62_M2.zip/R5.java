/*
 Author:-Rajesh Kumar Sheela
 Program;-5. void main(){
				int a, b;
				float f1,f2;
				printf(“%d%d”,a,b);
				printf(“%f%f”,f1,f2);
			} 
 
 */
public class R5 {
	public static void main(String[] args) {
		int a=0, b = 0;
		float f1=(float) 0.1,f2=(float) 0.2;
		System.out.println("Value of a :-"+a+" Value of b:-"+b);
		System.out.println("Value of f1 :-"+f1+"Value of f2:-"+f2);

	}

}
