/*
 Author:-Rajesh Kumar Sheela
 Program:-void main(){
			char x[] = {'H’,’E’,’L’,’L’,’O’};	// use String type in java
			char y[] = {'J’,’A’,’V’,’A’};	// use String type in java
			char z[] = {'W’,’O’,’R’,’L’,’D’};	// use String type in java
			printf(“%s\n%s\n%d”,x,y,x);
		}
 */
public class R4 {
	public static void main(String[] args) {
		char x[] = {'H','E','L','L','O'};
		char y[] = {'J','A','V','A'};
		char z[] = {'W','O','R','L','D'};
		System.out.print(x);
		System.out.print(" ");
		System.out.print(y);
		System.out.print(" ");
		System.out.print(z);

	}

}
