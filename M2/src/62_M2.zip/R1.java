/*
 Author:-Rajesh Kumar Sheela
 Program:-Write equivalent java programs of the following c programs   
 			1. void main(){
				int a, b,c;
				a = 10;
				b = 20;
				c = a+b;
				printf(“%d”,c);
			}
 */
public class R1 {
	public static void main(String[] args) {
		int a, b,c;
		a = 10;
		b = 20;
		c = a+b;
		System.out.println("Sum of numbers are:- "+c);

	}

}
