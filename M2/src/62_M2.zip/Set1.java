/*
 Author:-Rajesh Kumar Sheela
 Program:-Write a Java program which prints "PASS" if the int variable "mark" is more than or equal to 50; or prints "FAIL" otherwise.
 */
public class Set1 {
	public static void main(String[] args) {
		
		 int mark = 55;         // set the value of mark here!
	      System.out.println("The mark is " + mark);
	 
	      if (mark>=50 && mark<100) {
	         System.out.println("Pass");
	      } else {
	         System.out.println("fail");
	      }
	}

}
