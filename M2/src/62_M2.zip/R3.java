/*
 Author:-Rajesh Kumar Sheela
 Program:-3. void main(){
				char x=’*’,y;
				char ch[] = {'j’,’a’,’v’,’a’};
				y = '2’;
				printf(“%c %s%c”,x,ch,y);
			}
 */
public class R3 {
	public static void main(String[] args) {
		
		char x='*',y;
		char ch[] = {'j','a','v','a'};
		y = '2';
		System.out.print(x);
		System.out.print(ch);
		System.out.print(y);
		//System.out.printf(String.format("%s%s%s",x,ch,y));

	}

}
