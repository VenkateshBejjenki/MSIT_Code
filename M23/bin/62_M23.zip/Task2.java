import java.io.*;


public class Task2 {

	public static void main(String[] args) throws IOException  {
			FileInputStream fn=new FileInputStream("non-prime.txt");
			DataInputStream dn=new DataInputStream(fn);
			int i=0,k=0;
			try{
			while((i=dn.readInt())!=-1){
				
				if(i!=1&&i!=0){
					System.out.println(i);k++;
				}
			}
			System.out.println("Final Count is "+k);
			dn.close();
		}catch(Exception e){System.out.println(e.getMessage());}
		
		
	}
}
