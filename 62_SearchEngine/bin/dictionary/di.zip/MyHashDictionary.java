package dictionary;


class MainNode<K extends Comparable<K>,V>{
	K key;
	V value;
	MainNode<K,V> next;
	MainNode(K key,V h){
		this.value=h;
		this.key=key;
		this.next=null;
	}
}

public class MyHashDictionary <K extends Comparable<K>, V> implements DictionaryInterface <K,V>{

	MainNode<K,V>[] array = new MainNode[30];
	int size=0;
	public K[] getKeys() {
		String[] ss=new String[size];
		for (int i = 0,c=0; i < array.length; i++) {
			if(array[i]!=null){
				MainNode<K,V> temp=array[i];
				while(temp!=null){
					ss[c++]=(String) temp.key;
					temp=temp.next;
				}
				
			}
		}
		return (K[]) ss;
	}

	
	public V getValue(K str) {
		int k=(((String) str).charAt(0))%array.length;
		V val=null;
		MainNode<K,V> temp=array[k];
		while(temp!=null)
		{
			if(temp.key.equals(str))
			{
				val=temp.value;
				break;
			}
			temp=temp.next;
		}
		return val;
	}

	
	public void insert(K key, V value) {
		MainNode<K,V> temp=new MainNode<K,V>(key,value);
		int k=(((String) key).charAt(0))%array.length;
		System.out.println(key+" with key changed "+k);
		if(array[k]==null){
			array[k]=temp;
			size++;
		}
		else if(array[k].key.equals(key))
		{
			array[k].value=(V) (array[k].value+"|"+value);
			return;
		}
		else{
			MainNode<K,V> start=array[k];
			while(start.next!=null){
				if(start.key.equals(key))
				{
					start.value=(V) (start.value+"|"+value);
					size++;
					return;
				}
				start=start.next;
			}
			if(start.key.equals(key))
			{
				start.value=(V) (start.value+"|"+value);
				size++;
				return;
			}
			else{
			start.next=temp;
			size++;
			}
			
		}
		
	}

	
	public void remove(K key) {
		
		
	}

}
