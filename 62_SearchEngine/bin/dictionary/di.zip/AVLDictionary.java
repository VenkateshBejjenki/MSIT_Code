package dictionary;

public class AVLDictionary <K extends Comparable<K>, V> implements DictionaryInterface <K,V>{

	
	public K[] getKeys() {
		// TODO Auto-generated method stub
		return null;
	}

	
	public V getValue(K str) {
		// TODO Auto-generated method stub
		return null;
	}

	
	public void insert(K key, V value) {
		// TODO Auto-generated method stub
		
	}

	
	public void remove(K key) {
		// TODO Auto-generated method stub
		
	}

}
