
public class Addess {

	String city, state, country;
	
	
	public Addess(String city,String state,String country){
		this.city=city;
		this.state=state;
		this.country=country;
	}

	public Addess() {
		
	}
}
