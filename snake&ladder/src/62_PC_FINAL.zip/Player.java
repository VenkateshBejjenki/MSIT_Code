
class Player
{
	String Name;
	int age;
	int curr;

	public String toString() {
		
		return (Name+" "+age);
	}
	public Player(String name, int age) {
		this.Name=name;
		this.age=age;
	}
}