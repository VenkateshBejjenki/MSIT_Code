
public class Ladder {

	int start;
	int end; 
}
