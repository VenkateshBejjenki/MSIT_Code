
public class Snake {

	int head;
	int tail; 
}
