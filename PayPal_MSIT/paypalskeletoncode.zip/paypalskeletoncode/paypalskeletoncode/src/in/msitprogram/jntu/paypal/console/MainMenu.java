/**
 * 
 */
package in.msitprogram.jntu.paypal.console;

import java.io.IOException;
import java.util.Scanner;

/**
 * @author pg
 *
 */
public class MainMenu {
	
	public static void show() throws IOException{
		//show the welcome message with the main menu options
		
		//take the menu option as input from the console
		
		//take email address as input from the console
		
		//based on the given menu option instantiate the respective screens
	}

}
