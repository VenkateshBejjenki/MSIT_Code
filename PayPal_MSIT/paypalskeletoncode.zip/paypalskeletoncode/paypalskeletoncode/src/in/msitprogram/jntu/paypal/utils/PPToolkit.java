/**
 * 
 */
package in.msitprogram.jntu.paypal.utils;
import java.util.*;
/**
 * @author pg
 *
 */
public class PPToolkit {

	public static String generateActivationCode() 
	{
		
	    return "a23j5h";
	}

	public static void sendActivationCode(String phone) 
	{
		
		
	}

}
