package in.msitprogram.jntu.paypal.accounts;

public class Profile {
	
	private String name;
	private String address;
	private String phone;
	
	
}
